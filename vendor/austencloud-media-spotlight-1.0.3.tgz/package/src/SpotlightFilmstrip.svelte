<script lang="ts">
  import { getCropStyles, type MediaItem } from "./types.js";

  interface Props {
    items: MediaItem[];
    currentIndex: number;
    visible: boolean;
    onselect: (index: number) => void;
  }

  let { items, currentIndex, visible, onselect }: Props = $props();

  const BUFFER_ITEMS = 6;
  const EDGE_PADDING = 6;
  let containerEl: HTMLElement | null = $state(null);
  let scrollLeft = $state(0);
  let containerWidth = $state(0);
  let thumbnailSize = $state(60);
  let thumbnailGap = $state(4);

  const itemStride = $derived(thumbnailSize + thumbnailGap);
  const trackWidth = $derived(
    Math.max(0, items.length * itemStride - thumbnailGap + EDGE_PADDING * 2),
  );
  const visibleRange = $derived.by(() => {
    if (items.length === 0) return { start: 0, end: 0 };
    const start = Math.max(
      0,
      Math.floor(Math.max(0, scrollLeft - EDGE_PADDING) / itemStride) -
        BUFFER_ITEMS,
    );
    const visibleCount =
      Math.ceil(containerWidth / itemStride) + BUFFER_ITEMS * 2;
    return { start, end: Math.min(items.length, start + visibleCount) };
  });
  const visibleItems = $derived(
    items.slice(visibleRange.start, visibleRange.end).map((item, offset) => ({
      item,
      index: visibleRange.start + offset,
    })),
  );

  function readMeasurements(): void {
    if (!containerEl) return;
    const styles = getComputedStyle(containerEl);
    const thumbnail =
      containerEl.querySelector<HTMLElement>(".filmstrip-thumb:not(.active)") ??
      containerEl.querySelector<HTMLElement>(".filmstrip-thumb");
    thumbnailSize =
      (thumbnail ? Number.parseFloat(getComputedStyle(thumbnail).width) : 0) ||
      Number.parseFloat(
        styles.getPropertyValue("--spotlight-filmstrip-thumb-size"),
      ) ||
      60;
    thumbnailGap =
      Number.parseFloat(styles.getPropertyValue("--spotlight-filmstrip-gap")) ||
      4;
    containerWidth = containerEl.clientWidth;
  }

  $effect(() => {
    if (!containerEl) return;
    readMeasurements();
    const observer = new ResizeObserver(readMeasurements);
    observer.observe(containerEl);
    return () => observer.disconnect();
  });

  $effect(() => {
    if (!containerEl || !visible || containerWidth === 0) return;
    const target =
      EDGE_PADDING +
      currentIndex * itemStride -
      containerWidth / 2 +
      thumbnailSize / 2;
    const max = Math.max(0, trackWidth - containerWidth);
    containerEl.scrollTo({ left: Math.max(0, Math.min(max, target)) });
  });

  function handleScroll(event: Event): void {
    scrollLeft = (event.currentTarget as HTMLElement).scrollLeft;
  }

  function getThumbnailUrl(item: MediaItem): string {
    return item.thumbnailUrl ?? item.previewUrl ?? item.url;
  }
</script>

<div
  class="spotlight-filmstrip"
  class:visible
  role="listbox"
  aria-label="Thumbnail navigation"
  aria-orientation="horizontal"
>
  <div bind:this={containerEl} class="filmstrip-scroll" onscroll={handleScroll}>
    <div class="filmstrip-track" style:width="{trackWidth}px">
      {#each visibleItems as { item, index } (item.id)}
        <button
          class="filmstrip-thumb"
          class:active={index === currentIndex}
          style:left="{EDGE_PADDING + index * itemStride}px"
          onclick={() => onselect(index)}
          role="option"
          aria-selected={index === currentIndex}
          aria-setsize={items.length}
          aria-posinset={index + 1}
          aria-label={item.alt ?? item.name ?? `Item ${index + 1}`}
          tabindex={index === currentIndex ? 0 : -1}
        >
          {#if item.type === "image"}
            {@const crop = getCropStyles(item.crop)}
            {#if item.crop}
              <div class="thumb-crop-wrapper" style={crop.containerStyle}>
                <img
                  src={getThumbnailUrl(item)}
                  alt=""
                  class="thumb-image thumb-image-cropped"
                  style={crop.mediaStyle}
                  loading="lazy"
                  draggable="false"
                />
              </div>
            {:else}
              <img
                src={getThumbnailUrl(item)}
                alt=""
                class="thumb-image"
                loading="lazy"
                draggable="false"
              />
            {/if}
          {:else}
            <div class="thumb-video">
              <span class="video-icon" aria-hidden="true">▶</span>
            </div>
          {/if}

          {#if item.needsEditing}
            <span class="thumb-badge" aria-hidden="true">!</span>
          {/if}
        </button>
      {/each}
    </div>
  </div>
</div>

<style>
  .spotlight-filmstrip {
    position: absolute;
    right: 0;
    bottom: 0;
    left: 0;
    height: var(--spotlight-filmstrip-height, 80px);
    padding-bottom: var(--spotlight-safe-area-bottom, 0px);
    background: linear-gradient(transparent, rgba(0, 0, 0, 0.78));
    z-index: var(--spotlight-z-filmstrip, 1003);
    opacity: 0;
    transform: translateY(100%);
    transition:
      opacity var(--spotlight-duration-out, 250ms) var(--spotlight-ease-out),
      transform var(--spotlight-duration-out, 250ms) var(--spotlight-ease-out);
    pointer-events: none;
  }

  .spotlight-filmstrip.visible {
    opacity: 1;
    transform: translateY(0);
    pointer-events: auto;
  }

  .filmstrip-scroll {
    width: 100%;
    height: 100%;
    padding-block: 10px;
    overflow-x: auto;
    overflow-y: hidden;
    scroll-behavior: smooth;
    scrollbar-width: none;
  }

  .filmstrip-scroll::-webkit-scrollbar {
    display: none;
  }

  .filmstrip-track {
    position: relative;
    height: var(--spotlight-filmstrip-thumb-size, 60px);
  }

  .filmstrip-thumb {
    position: absolute;
    top: 0;
    width: var(--spotlight-filmstrip-thumb-size, 60px);
    height: var(--spotlight-filmstrip-thumb-size, 60px);
    padding: 0;
    overflow: hidden;
    border: 2px solid transparent;
    border-radius: 6px;
    background: rgba(255, 255, 255, 0.1);
    opacity: 0.58;
    cursor: pointer;
    transform: scale(0.92);
    transition:
      transform var(--spotlight-duration-out, 250ms) var(--spotlight-ease-out),
      opacity var(--spotlight-duration-out, 250ms) var(--spotlight-ease-out),
      border-color var(--spotlight-duration-out, 250ms)
        var(--spotlight-ease-out);
  }

  .filmstrip-thumb:hover {
    border-color: rgba(255, 255, 255, 0.55);
    opacity: 0.86;
    transform: scale(0.98);
  }

  .filmstrip-thumb:focus-visible {
    outline: 2px solid var(--spotlight-filmstrip-active-border, white);
    outline-offset: 2px;
  }

  .filmstrip-thumb.active {
    border-color: var(--spotlight-filmstrip-active-border, white);
    opacity: 1;
    transform: scale(var(--spotlight-filmstrip-active-scale, 1.08));
    z-index: 1;
  }

  .thumb-crop-wrapper,
  .thumb-image,
  .thumb-video {
    width: 100%;
    height: 100%;
  }

  .thumb-crop-wrapper {
    overflow: hidden;
  }

  .thumb-image {
    object-fit: cover;
    pointer-events: none;
  }

  .thumb-image-cropped {
    transform-origin: center;
  }

  .thumb-video {
    display: grid;
    place-items: center;
    background: rgba(0, 0, 0, 0.5);
  }

  .video-icon {
    color: white;
    font-size: 20px;
  }

  .thumb-badge {
    display: grid;
    position: absolute;
    top: 2px;
    right: 2px;
    width: 16px;
    height: 16px;
    place-items: center;
    border-radius: 50%;
    background: var(--spotlight-needs-editing-color, rgb(245, 158, 11));
    color: black;
    font-size: 12px;
    font-weight: bold;
  }

  @media (prefers-reduced-motion: reduce) {
    .spotlight-filmstrip,
    .filmstrip-thumb {
      transition: none;
    }

    .filmstrip-scroll {
      scroll-behavior: auto;
    }
  }
</style>
