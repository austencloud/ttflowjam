<script lang="ts">
  import { getCropStyles, type MediaItem } from "./types.js";

  interface Props {
    item: MediaItem;
    scale?: number;
    panX?: number;
    panY?: number;
    skipFadeIn?: boolean;
  }

  let {
    item,
    scale = 1,
    panX = 0,
    panY = 0,
    skipFadeIn = false,
  }: Props = $props();

  let fullLoaded = $state(false);
  let fullError = $state(false);
  let previewLoaded = $state(false);
  let previewError = $state(false);
  let previousKey = $state("");

  const previewUrl = $derived(
    item.previewUrl && item.previewUrl !== item.url ? item.previewUrl : null,
  );
  const cropStyles = $derived(getCropStyles(item.crop));
  const anyLoaded = $derived(fullLoaded || previewLoaded);
  const unavailable = $derived(fullError && (!previewUrl || previewError));

  $effect(() => {
    const key = `${item.id}:${item.url}:${previewUrl ?? ""}`;
    if (key === previousKey) return;
    previousKey = key;
    fullLoaded = false;
    fullError = false;
    previewLoaded = false;
    previewError = false;
  });
</script>

<div
  class="spotlight-image-container"
  style:--scale={scale}
  style:--pan-x="{panX}px"
  style:--pan-y="{panY}px"
>
  {#if !anyLoaded && !unavailable}
    <div class="spotlight-image-loading">
      <div class="spotlight-spinner" aria-label="Loading"></div>
    </div>
  {/if}

  {#if unavailable}
    <div class="spotlight-image-error" role="status">
      <span class="error-icon" aria-hidden="true">⚠</span>
      <span>This image is unavailable</span>
    </div>
  {:else if item.crop}
    <div
      class="spotlight-crop-wrapper"
      style="{cropStyles.containerStyle} overflow: hidden; max-width: 100%; max-height: 100%;"
    >
      {#if previewUrl}
        <img
          src={previewUrl}
          alt=""
          aria-hidden="true"
          class="spotlight-image spotlight-image-cropped preview"
          class:loaded={previewLoaded}
          class:replaced={fullLoaded}
          class:instant={skipFadeIn}
          style={cropStyles.mediaStyle}
          draggable="false"
          onload={() => {
            previewLoaded = true;
            previewError = false;
          }}
          onerror={() => {
            previewError = true;
          }}
        />
      {/if}
      <img
        src={item.url}
        srcset={item.srcset}
        sizes={item.sizes ?? "100vw"}
        alt={item.alt ?? item.name ?? "Media"}
        class="spotlight-image spotlight-image-cropped full"
        class:loaded={fullLoaded}
        class:instant={skipFadeIn}
        style={cropStyles.mediaStyle}
        draggable="false"
        onload={() => {
          fullLoaded = true;
          fullError = false;
        }}
        onerror={() => {
          fullError = true;
        }}
      />
    </div>
  {:else}
    {#if previewUrl}
      <img
        src={previewUrl}
        alt=""
        aria-hidden="true"
        class="spotlight-image preview"
        class:loaded={previewLoaded}
        class:replaced={fullLoaded}
        class:instant={skipFadeIn}
        draggable="false"
        onload={() => {
          previewLoaded = true;
          previewError = false;
        }}
        onerror={() => {
          previewError = true;
        }}
      />
    {/if}
    <img
      src={item.url}
      srcset={item.srcset}
      sizes={item.sizes ?? "100vw"}
      alt={item.alt ?? item.name ?? "Media"}
      class="spotlight-image full"
      class:loaded={fullLoaded}
      class:instant={skipFadeIn}
      draggable="false"
      onload={() => {
        fullLoaded = true;
        fullError = false;
      }}
      onerror={() => {
        fullError = true;
      }}
    />
  {/if}
</div>

<style>
  .spotlight-image-container {
    display: flex;
    position: relative;
    width: 100%;
    height: 100%;
    align-items: center;
    justify-content: center;
    transform: scale(var(--scale, 1))
      translate(var(--pan-x, 0), var(--pan-y, 0));
    transform-origin: center;
  }

  .spotlight-crop-wrapper {
    display: flex;
    position: relative;
    width: 100%;
    height: 100%;
    align-items: center;
    justify-content: center;
    border-radius: 4px;
  }

  .spotlight-image {
    position: absolute;
    max-width: 100%;
    max-height: 100%;
    object-fit: contain;
    opacity: 0;
    transition: opacity var(--spotlight-duration-crossfade, 80ms) ease-out;
    pointer-events: none;
  }

  .spotlight-image.preview.loaded,
  .spotlight-image.full.loaded {
    opacity: 1;
  }

  .spotlight-image.preview.replaced {
    opacity: 0;
  }

  .spotlight-image-cropped {
    width: 100%;
    height: 100%;
    max-width: none;
    max-height: none;
    object-fit: cover;
  }

  .spotlight-image.instant {
    transition: none;
  }

  .spotlight-image-loading {
    display: grid;
    position: absolute;
    place-items: center;
  }

  .spotlight-spinner {
    width: 48px;
    height: 48px;
    border: 3px solid rgba(255, 255, 255, 0.2);
    border-top-color: white;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
  }

  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }

  .spotlight-image-error {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 12px;
    padding: 24px 32px;
    border-radius: 8px;
    background: var(--spotlight-error-bg, rgba(0, 0, 0, 0.5));
    color: var(--spotlight-error-color, rgba(255, 255, 255, 0.8));
  }

  .error-icon {
    font-size: 32px;
  }

  @media (prefers-reduced-motion: reduce) {
    .spotlight-spinner {
      animation: none;
      border-top-color: white;
    }

    .spotlight-image {
      transition: none;
    }
  }
</style>
